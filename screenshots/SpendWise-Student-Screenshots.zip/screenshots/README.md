# SpendWise Student — Screenshots

These screenshots show the main pages of the SpendWise Student personal finance and budget tracker.

## Login Page
![Login Page](login.png)

## Financial Dashboard
![Financial Dashboard](dashboard.png)

## Transaction History
![Transaction History](transactions.png)

## Add Transaction
![Add Transaction](add-transaction.png)
